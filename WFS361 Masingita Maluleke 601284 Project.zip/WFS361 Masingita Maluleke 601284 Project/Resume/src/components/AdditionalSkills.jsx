import React, { forwardRef } from "react";
import "./Style.css";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const languageData = [
  { name: "Xitsonga", level: 100 },
  { name: "English", level: 95 },
  { name: "Sepedi", level: 80 },
  { name: "Zulu", level: 65 },
  { name: "Xhosa", level: 45 },
  { name: "Venda", level: 50 },
  { name: "Spanish", level: 40 },
  { name: "French", level: 30 },
  { name: "Portuguese", level: 20 }
];

const Languages = forwardRef((props, ref) => {
  return (
    <section className="languages-container" ref={ref} id="languages">
      <h2 className="languages-title">Additional Skills</h2>
      <p className="languages-subtitle">Languages I speak and learning</p>
      <br />
      <p className="languages-content">Imagine traveling to a new country and not being able to greet someone in their native language — the shock would be real! Learning multiple languages, both spoken and programming, allows me to connect with people from different backgrounds and cultures. As an IT student, I understand that technology knows no borders, and being multilingual empowers me to collaborate more effectively in a globalized world. Whether it’s understanding a piece of code in Python or engaging with someone in Spanish, language is a tool that bridges gaps, opens doors, and nurtures creativity. By speaking multiple languages, I’m not just learning to communicate, but also expanding my ability to think, innovate, and problem-solve in ways that are culturally and technically enriched.</p>

      <div className="languages-list">
        {languageData.map((lang, index) => (
          <div key={index} className="language-card">
            <h4>{lang.name}</h4>
            <span>{lang.level}% proficient</span>
          </div>
        ))}
      </div>

      <div className="chart-container">
        <p className="chart-para">Included this chart just to add more vibe to my portfolio. So with this chart, it just shows the pecentage of how good I am with understanding reading and speaking a language</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={languageData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="level" fill="#4b5320" radius={[10, 10, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
});

export default Languages;
