import React, { useState } from "react";
import "./Style.css"; 
import { Hand, Monitor, Rocket, MousePointerClick } from "lucide-react";


const HomePage = () => {
  const [greeting, setGreeting] = useState("");

  const handleButtonClick = () => {
    setGreeting("Hey! Scroll down to see more about me, and see more amazing things available on this webpage.");
  };

  return (
    <div className="home-page" id="home">
      <img
        src="src\components\Masingita Resume.jpg"
        alt="Profile"
        className="profile-image"
      />
      <h1>
        Hi, I'm Masingita <Hand size={24} className="icon-hand" />
      </h1>
      <p className="job-title">
        <Monitor size={20} className="icon" /> Front-End Developer
      </p>

      <p className="intro-text">
        I create seamless user experiences while bringing innovative solutions
        to life. Let’s collaborate and turn your vision into something truly
        awesome!
      </p>

      <button className="say-hello-button" onClick={handleButtonClick}>
        <Rocket size={18} className="icon-rocket" /> Say Hello
      </button>

      {greeting && <p className="greeting">{greeting}</p>}

      <div className="scroll-down">
        <p>
          Scroll Down <MousePointerClick size={18} className="icon" />
        </p>
      </div>
    </div>
  );
};

export default HomePage;
