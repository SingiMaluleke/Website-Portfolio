import React from "react";
import "./Style.css";

const Header = ({ onHomeClick, onAboutClick, onSkillsClick, onEducationClick, onAddSkillsClick, onContactClick, onProjectsClick }) => {
  return (
    <header className="header">
      <div className="header-left">
        <h1 className="header-title">Masingita</h1>
      </div>
      <nav className="header-nav">
        <ul className="header-nav-list">
          <li className="header-nav-item">
            <a href="#home" onClick={onHomeClick}>Home</a>
          </li>
          <li className="header-nav-item">
            <a href="#about" onClick={onAboutClick}>About</a>
          </li>
          <li className="header-nav-item">
            <a href="#skills" onClick={onSkillsClick}>Skills</a>
          </li>
          <li className="header-nav-item">
            <a href="#education" onClick={onEducationClick}>Education</a>
          </li>
          <li className="header-nav-item">
            <a href="#projects" onClick={onProjectsClick}>Projects Experience</a>
          </li>
          <li className="header-nav-item">
            <a href="#addSkills" onClick={onAddSkillsClick}>Additional Skills</a>
          </li>
          <li className="header-nav-item">
            <a href="#contact" onClick={onContactClick}>Contact</a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;




