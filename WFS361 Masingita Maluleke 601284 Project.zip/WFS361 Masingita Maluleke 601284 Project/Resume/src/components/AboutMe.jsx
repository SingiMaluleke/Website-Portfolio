import React, { forwardRef } from "react";
import { Briefcase, Headphones, Lightbulb } from "lucide-react"; // Import icons
import "./Style.css";

const AboutMe = forwardRef((props, ref) => {
  return (
    <section ref={ref} id="about" className="about-me">
      <h2 className="section-title">About Me</h2>
      <p className="section-subtitle">My Introduction</p>

      <div className="about-container">
        <div className="about-image">
          <img src="\src\components\WhatsApp Image 2025-04-17 at 11.02.56_0c03949f.jpg" alt="Profile" />
        </div>

        <div className="about-content">
          <ProfileSection />
          
          <div className="about-info">
            <div className="info-box">
              <Lightbulb size={24} />  
              <h3>Experience</h3>
              <p>2,5+</p>
            </div>
            <div className="info-box">
              <Briefcase size={24} />
              <h3>Completed</h3>
              <p>4+ Projects</p>
            </div>
            <div className="info-box">
              <Headphones size={24} /> 
              <h3>Support</h3>
              <p>Online 8-10hrs</p>
            </div>
          </div>

              <a href="/Masingita Maluleke Resume.pdf" download="Masingita Maluleke_Resume.pdf" className="download-btn">Download CV</a> 
        </div>
      </div>
    </section>
  );
});

const ProfileSection = () => {
  return (
    <div className="profile-section">
      <p>
        I'm a Software Development student at Belgium Campus ITVersity, driven by a passion for technology and innovation. My skills span across multiple programming languages, including Python, C#, Java, and SQL, and I've gained valuable experience in software testing, data analysis, and problem-solving.
        I’m passionate about creating efficient and user-friendly applications, with a keen interest in AI and how it is transforming the way we interact with technology. Currently, I’m helping develop a website for the Sizofakulwazi foundation, focusing on making the user experience seamless and intuitive.</p>
        <br></br>
        <p>Imagine having to work with AI in our daily lives. Look at how our life is now—everything is just amazing! From personalized recommendations to smart home devices, the possibilities are endless. This fascination with AI is what drives me to explore its potential further. In fact, I am currently working on a year-long 
        project involving AI hand gesture recognition, where I am developing a system that can interpret human gestures for a more interactive and intuitive user experience.
        The world of technology is evolving rapidly, and I’m excited to be part of this change. Whether it's coding an application, learning a new programming language, or experimenting with AI, I’m always looking for opportunities to challenge myself and grow.
      </p>
    </div>
  );
};

export default AboutMe;



