import "./Style.css";
import React, { forwardRef, useState } from "react";
import { GraduationCap, Briefcase, Calendar } from "lucide-react";

const Education = forwardRef((props, ref) => {
  const [activeTab, setActiveTab] = useState("education");

  // Date states
  const [eduDate, setEduDate] = useState("2023-02-06");
  const [productDate, setProductDate] = useState("2023-04-03");
  const [webDate, setWebDate] = useState("2023-05-01");
  const [uxDate, setUxDate] = useState("2025-03-31");
  const [pythonDate, setPythonDate] = useState("2025-03-15");

  return (
    <section ref={ref} id="education-experience" className="qualification">
      <h2 className="title">Education/Qualification</h2>
      <p className="subtitle">My Personal Journey</p>

      <div className="qualification-tabs">
        <span
          className={`tab ${activeTab === "education" ? "active" : ""}`}
          onClick={() => setActiveTab("education")}
        >
          <GraduationCap size={24} /> Education
        </span>
        <span
          className={`tab ${activeTab === "experience" ? "active" : ""}`}
          onClick={() => setActiveTab("experience")}
        >
          <Briefcase size={24} /> Experience
        </span>
      </div>

      <div className="qualification-content">
        {activeTab === "education" ? (
          <>
            <div className="qualification-column">
              <div className="qualification-item">
                <h3>Belgium Campus ITVersity</h3>
                <p>Final-Year Student | Software Development</p>
                <div className="date-picker">
                  <Calendar size={16} />
                  <input
                    type="date"
                    value={eduDate}
                    onChange={(e) => setEduDate(e.target.value)}
                    className="date-input"
                  />
                  --present
                </div>
              </div>

              <div className="qualification-item">
                <h3>Coursework</h3>
                <p>Software Engineering, Database Management, OOP, System Design</p>
              </div>

              <div className="qualification-item">
                <h3>Academic Projects</h3>
                <p>Developed multiple applications with CRUD operations, data structures, and UI/UX principles</p>
              </div>
            </div>

            <div className="qualification-line"></div>
          </>
        ) : (
          <>
            <div className="qualification-column">
              <div className="qualification-item">
                <h3>Product Designer</h3>
                <p>Microsoft</p>
                <div className="date-picker">
                  <Calendar size={16} />
                  <input
                    type="date"
                    value={productDate}
                    onChange={(e) => setProductDate(e.target.value)}
                    className="date-input"
                  />
                </div>
              </div>

              <div className="qualification-item">
                <h3>Web Designer</h3>
                <p>Figma</p>
                <div className="date-picker">
                  <Calendar size={16} />
                  <input
                    type="date"
                    value={webDate}
                    onChange={(e) => setWebDate(e.target.value)}
                    className="date-input"
                  />
                </div>
              </div>
            </div>

            <div className="qualification-line"></div>

            <div className="qualification-column">
              <div className="qualification-item">
                <h3>UX Designer</h3>
                <p>Portfolio</p>
                <div className="date-picker">
                  <Calendar size={16} />
                  <input
                    type="date"
                    value={uxDate}
                    onChange={(e) => setUxDate(e.target.value)}
                    className="date-input"
                  />
                </div>
              </div>

              {/* Python Experience Entry */}
              <div className="qualification-item">
                <h3>Python Developer</h3>
                <p>AI Hand Gesture</p>
                <div className="date-picker">
                  <Calendar size={16} />
                  <input
                    type="date"
                    value={pythonDate}
                    onChange={(e) => setPythonDate(e.target.value)}
                    className="date-input"
                  />
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </section>
  );
});

export default Education;
