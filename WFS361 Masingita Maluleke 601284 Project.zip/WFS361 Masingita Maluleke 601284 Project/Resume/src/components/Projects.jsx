import React, { useState, forwardRef } from 'react';
import { Code, FileCode, Terminal } from 'lucide-react';
import './Style.css';

const projects = [
    {
        title: 'Employee Management System',
        tech: 'Java',
        description: 'A desktop Java Swing app with JavaDB using OOP, CRUD operations for employees, departments, and payroll.',
        icon: <Code size={32} className="project-icon" />,
        link: 'https://github.com/SingiMaluleke/employee-management-system',
        //I havent yet uploded the projects yet apologies
    },
    {
        title: 'Slip Printing App',
        tech: 'JavaScript/HTML/CSS',
        description: 'A web app allowing users to print purchase slips after transactions.',
        icon: <FileCode size={32} className="project-icon" />,
        link: 'https://github.com/SingiMaluleke/slip-printing-app',
    },
    {
        title: 'Portfolio Website',
        tech: 'React',
        description: 'A personal portfolio showcasing my background, skills, and projects. Includes responsive design and animations.',
        icon: <Code size={32} className="project-icon" />,
        link: 'https://github.com/SingiMaluleke/portfolio',
    },
    {
        title: 'PRJ381 Hand Gesture Recognition',
        tech: 'Python/OpenCV/React',
        description: 'A real-time hand gesture recognition project integrated with a React front-end.',
        icon: <Terminal size={32} className="project-icon" />,
        link: 'https://github.com/SingiMaluleke/prj381-gesture-recognition',
    },
];

const Projects = forwardRef(({ onProjectClick }, ref) => {
  const [selected, setSelected] = useState(null);

  const handleClick = (index) => {
    setSelected(selected === index ? null : index);  // Toggle the selected project
    onProjectClick(index);  // Call the scroll function passed from App.jsx
  };

  return (
    <section ref={ref} id="projects" className="projects-container">
      <h2 className="projects-title">Projects</h2>
      <p className="projects-subtitle">A showcase of selected projects and the technologies used</p>
      <div className="projects-grid">
        {projects.map((project, index) => (
          <div
            key={index}
            className="project-card"
            onClick={() => handleClick(index)}
          >
            <div className="project-icon-container">{project.icon}</div>
            <h3 className="project-name">{project.title}</h3>
            <p className="project-tech">{project.tech}</p>
            <div className="project-details">
              <p>{project.description}</p>
              <a
                href={project.link}
                target="_blank"
                rel="noopener noreferrer"
                className="view-project-btn"
              >
                View Project
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
});

export default Projects;
