import React, { useRef } from "react";
import { Phone, Mail, Github } from "lucide-react";
import emailjs from "@emailjs/browser";
import "./Style.css";

const Contact = () => {
  const form = useRef();

  const sendEmail = async (e) => {
    e.preventDefault();
  
    try {
      const result = await emailjs.sendForm(
        "service_9kdgmoc",      
        "template_zakeivt",     
        form.current,          
        "b9sTaimFkKRAhA5kx"       
      );
  
      console.log("Email successfully sent:", result.text);
      alert("Message sent successfully!");
      form.current.reset();
    } catch (error) {
      console.error("Email failed to send:", error);
      alert("Failed to send message. Please try again.");
      form.current.reset();
    }
  };

  return (
    <section id="contact" className="contact-container">
      <div className="contact-content">
        <div className="contact-info">
          <h3>Get in Touch</h3>
          <p>I'd love to collaborate on a project or chat! Fill out this form, or message me on my socials.</p>
          <p><Phone size={18} /> <a href="tel:+27729331994">072 933 1994</a></p>
          <p><Mail size={18} /> <a href="mailto:singimiracles@gmail.com">singimiracles@gmail.com</a></p>
          <p><Github size={18} /> <a href="https://github.com/SingiMaluleke" target="_blank" rel="noopener noreferrer">GitHub</a></p>
        </div>

        <div className="contact-form">
          <h3>Send me a message</h3>
          <form ref={form} onSubmit={sendEmail}>
            <input type="text" name="user_name" placeholder="Name" required />
            <input type="email" name="user_email" placeholder="Email" required />
            <input type="text" name="subject" placeholder="Subject" required />
            <textarea name="message" placeholder="Your Message" required></textarea>
            <button type="submit" className="send-btn">Send Message</button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
