import React from "react";
import "./Style.css"; 
import { Instagram, Facebook, MessageCircleMore } from "lucide-react";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-contact">
          <h3>More social platforms that you can find me on</h3>
        </div>
        <div className="footer-social">
          <a href="https://www.instagram.com/singi_maluks?" target="_blank" rel="noopener noreferrer">
            <Instagram size={22} />
          </a>
          <a href="https://www.facebook.com/share" target="_blank" rel="noopener noreferrer">
            <Facebook size={22} />
          </a>
          <a href="https://wa.me/27729331994" target="_blank" rel="noopener noreferrer">
            <MessageCircleMore size={22} />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;



