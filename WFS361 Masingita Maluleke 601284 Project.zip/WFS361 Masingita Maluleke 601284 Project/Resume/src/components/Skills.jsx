import React from "react";
import "./Style.css";
import { Code, Server } from "lucide-react";

const Skills = () => {
  return (
    <section className="skills-container" id="skills">
      <h2 className="skills-title">Skills</h2>
      <p className="skills-subtitle">My technical level</p>

      <div className="skills-grid">
        {/* Frontend Skills */}
        <div className="skills-card">
          <h3 className="skills-heading">
            <Code size={18} /> Frontend Developer
          </h3>
          <ul>
            <li><strong>HTML</strong><span>Advanced</span></li>
            <li><strong>JavaScript</strong><span>Intermediate</span></li>
            <li><strong>Figma</strong><span>Intermediate</span></li>
          </ul>
        </div>

        {/* Backend Skills */}
        <div className="skills-card">
          <h3 className="skills-heading">
            <Server size={18} /> Backend Developer
          </h3>
          <ul>
            <li><strong>Java</strong><span>Intermediate</span></li>
            <li><strong>Python</strong><span>Intermediate</span></li>
            <li><strong>Website Development</strong><span>Advanced</span></li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Skills;
