import React, { useRef } from "react";
import './App.css';
import Header from './components/header.jsx';
import Contact from './components/Contact.jsx';
import Education from './components/Education.jsx';
import AboutMe from './components/AboutMe.jsx';
import Home from './components/Home.jsx';
import Skills from './components/Skills.jsx';
import AdditionalSkills from './components/AdditionalSkills.jsx';
import Footer from './components/Footer.jsx';
import Projects from './components/Projects.jsx';  


const App = () => {
  const homeRef = useRef(null);
  const aboutRef = useRef(null);
  const educationRef = useRef(null);
  const projectsRef = useRef(null);  
  const addSkillsRef = useRef(null);
  const contactRef = useRef(null);

  const handleScrollToSection = (ref) => {
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="app-container">
    <Header
      onHomeClick={() => handleScrollToSection(homeRef)}
      onAboutClick={() => handleScrollToSection(aboutRef)}
      onEducationClick={() => handleScrollToSection(educationRef)}
      onProjectsClick={() => handleScrollToSection(projectsRef)}
      onAddSkillsClick={() => handleScrollToSection(addSkillsRef)}
      onContactClick={() => handleScrollToSection(contactRef)}
    />

    <div className="border-page">
      <Home ref={homeRef} />
      <AboutMe ref={aboutRef} />
      <Skills />
      <Education ref={educationRef} />
      <Projects ref={projectsRef} />
      <AdditionalSkills ref={addSkillsRef} />
      <Contact ref={contactRef} />
    </div>

    <Footer />
  </div>
  );
};

export default App;